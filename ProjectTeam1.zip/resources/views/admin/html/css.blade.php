<link rel="canonical" href="https://www.wrappixel.com/templates/materialpro/">
<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">

@yield('center-css')
<!-- Custom CSS -->
<link href="../../dist/css/style.min.css" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
{{--<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>--}}
{{--<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>--}}







{{--<link rel="stylesheet" href="/admin/plugins/fontawesome-free/css/all.min.css">--}}
{{--<!-- Ionicons -->--}}
{{--<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">--}}
{{--<!-- Tempusdominus Bbootstrap 4 -->--}}
{{--<link rel="stylesheet" href="/admin/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">--}}
{{--<!-- iCheck -->--}}
{{--<link rel="stylesheet" href="/admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css">--}}
{{--<!-- JQVMap -->--}}
{{--<link rel="stylesheet" href="/admin/plugins/jqvmap/jqvmap.min.css">--}}
{{--<!-- Theme style -->--}}
{{--<link rel="stylesheet" href="/admin/dist/css/adminlte.min.css">--}}
{{--<!-- overlayScrollbars -->--}}
{{--<link rel="stylesheet" href="/admin/plugins/overlayScrollbars/css/OverlayScrollbars.min.css">--}}
{{--<!-- Daterange picker -->--}}
{{--<link rel="stylesheet" href="/admin/plugins/daterangepicker/daterangepicker.css">--}}
{{--<!-- summernote -->--}}
{{--<link rel="stylesheet" href="/admin/plugins/summernote/summernote-bs4.css">--}}
{{--<!-- Google Font: Source Sans Pro -->--}}
{{--<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">--}}

{{--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">--}}

{{--<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>--}}

{{--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>--}}
