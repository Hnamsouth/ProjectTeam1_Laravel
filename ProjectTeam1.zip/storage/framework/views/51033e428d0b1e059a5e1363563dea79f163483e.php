

<?php $__env->startSection('main-content'); ?>
    <div class="container">
        <section>
        <div class="row">
            <?php $__currentLoopData = $acc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="mb-2">
                            <h3 class="mb-0"><?php echo e($item->name); ?></h3>
                        </div>
                        <p class="mb-3 card-subtitle"><?php echo e($item->name_dev); ?></p>
                        <div class="row">
                            <div class="col-sm-6 col-lg-4 col-xl-3">
                                    <img

                                        src="<?php echo e($item->img); ?>"
                                        alt="image"
                                        class="rounded mb-3"
                                        width="250"
                                    />
                            </div>
                            <div class="col-sm-12 col-lg-8 col-xl-9 ">
                                <div class="row">
                                    <div class="col-md-12 col-xl-3">
                                        <h5>BENEFIT</h5>
                                        <p>No joining & annual fee required. Lifetime support.</p>
                                    </div>
                                    <div class="col-md-12 col-xl-3">
                                        <h5>OUTSTANDING OFFER</h5>
                                        <p><?php echo e($item->special_offer); ?></p>
                                    </div>
                                    <div class="col-md-12 col-xl-3">
                                        <h5>CONDITIONS</h5>
                                        <p><?php echo e($item->target_customers); ?></p>
                                    </div>
                                    <div class="col-md-12 col-xl-3">
                                        <a href="<?php echo e(route('acc.register',['acc_type'=>$item->name_dev])); ?>" class="btn btn-primary w-100">Apply now</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/customer/page/account_list.blade.php ENDPATH**/ ?>