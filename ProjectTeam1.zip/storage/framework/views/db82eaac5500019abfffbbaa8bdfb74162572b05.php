<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <base href="/"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.108.0">


    <title><?php echo $__env->yieldContent('title','Layout'); ?></title>
    <?php echo $__env->yieldContent('head-js'); ?>
    <?php echo $__env->yieldContent('before-css'); ?>
    <?php echo $__env->make('user.html.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('after-css'); ?>
</head>

<body>
    <nav>
        <?php echo $__env->make('user.html.nav.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
<?php echo $__env->yieldContent('custom-nav'); ?>
    <main >
        <?php echo $__env->yieldContent('main-content'); ?>
    </main>


<?php echo $__env->yieldContent('footer'); ?>

<?php echo $__env->yieldContent('before-js'); ?>
<?php echo $__env->make('user.html.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('after-js'); ?>

</body>
</html>
<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/user/layout.blade.php ENDPATH**/ ?>