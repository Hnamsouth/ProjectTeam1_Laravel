<?php $__env->startSection('before-css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
    <div class="container-fluid">
        <div class="card">
            <div class="card-header text-center">
                <h3 class="card-title">Complete Transaction</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-12">
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">AMOUNT:  </span> <span class="fs-3 text-bg-light-gray" id="info_amount"><?php echo e($trans->amount); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">Transactions Code:  </span> <span class="fs-3 text-bg-light-gray" id="info_amount"><?php echo e($trans->id); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">FROM ACCOUNT:  </span> <span class="fs-3 text-bg-light-gray" id="info_from_acc"><?php echo e($trans->from_number); ?></span></div>
                        <hr/>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">TO ACCOUNT:  </span> <span class="fs-3 text-bg-light-gray" id="info_to_acc"><?php echo e($trans->to_number); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">ACCOUNT NAME:  </span> <span class="fs-3 text-bg-light-gray" id="info_acc_name"><?php echo e($trans->account_holder_name); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">BANK NAME:  </span> <span class="fs-3 text-bg-light-gray" id="info_bank_name"><?php echo e($trans->bank_name); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">DATE:  </span> <span class="fs-3 text-bg-light-gray" id="info_date"><?php echo e($trans->created_at); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">FEES:  </span> <span class="fs-3 text-bg-light-gray" id="info_fees"><?php echo e($trans->fees); ?></span></div>
                        <div class="mb-4"> <span class="fs-3 fw-semibold text-cl-gray me-2">DESCRIPTION:  </span> <span class="fs-3 text-bg-light-gray" id="info_description"><?php echo e($trans->description); ?></span></div>
                    </div>
                </div>
            </div>
            <div class="card-footer text-center">
                <a type="button" class="btn btn-primary " href="<?php echo e(route('user.transfer.within-bank')); ?>">New Transfer</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/customer/forAuth/transfer/transfer_finish.blade.php ENDPATH**/ ?>