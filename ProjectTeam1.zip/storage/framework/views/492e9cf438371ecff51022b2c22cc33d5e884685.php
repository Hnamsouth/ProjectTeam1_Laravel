<!-- All Jquery -->
<!-- ============================================================== -->
<script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<!-- apps -->
<script src="../../user_p/dist/js/app.min.js"></script>
<script src="../../user_p/dist/js/app.init.mini-sidebar.js"></script>
<script src="../../user_p/dist/js/app-style-switcher.js"></script>
<!-- slimscrollbar scrollbar JavaScript -->
<script src="../../assets/libs/perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
<script src="../../assets/extra-libs/sparkline/sparkline.js"></script>
<!--Wave Effects -->
<script src="../../user_p/dist/js/waves.js"></script>
<!--Menu sidebar -->
<script src="../../user_p/dist/js/sidebarmenu.js"></script>
<!--Custom JavaScript -->
<script src="../../user_p/dist/js/feather.min.js"></script>
<script src="../../user_p/dist/js/custom.min.js"></script>


<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/user_p/html_u/script.blade.php ENDPATH**/ ?>