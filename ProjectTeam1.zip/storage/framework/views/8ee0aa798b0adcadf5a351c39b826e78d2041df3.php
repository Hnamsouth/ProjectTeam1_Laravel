


<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">



<link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/blog/">
<link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sidebars/">

<link href="/user/assets/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="https://fonts.googleapis.com/css?family=Playfair&#43;Display:700,900&amp;display=swap" rel="stylesheet">
<!-- Custom styles for this template -->
<link href="/user/assets/dist/css/blog.css" rel="stylesheet">
<link href="/user/assets/dist/css/sidebars.css" rel="stylesheet">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.3/font/bootstrap-icons.css">

<link href="/user/assets/dist/css/login.css" rel="stylesheet">
<link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/heroes/">
<link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/footers/">
<link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/navbar-fixed/">


<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/user/html/css.blade.php ENDPATH**/ ?>