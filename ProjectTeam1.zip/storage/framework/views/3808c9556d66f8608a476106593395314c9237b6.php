<form action="<?php echo e(route('upfile')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="file" name="image" max="100000">
    <button type="submit" > submit</button>
</form>
<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/user/uoload_file_demo.blade.php ENDPATH**/ ?>