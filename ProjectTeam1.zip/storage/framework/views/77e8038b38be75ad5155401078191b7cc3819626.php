<link rel="canonical" href="https://www.wrappixel.com/templates/materialpro/">
<!-- Favicon icon -->
<link rel="icon" type="image/png" sizes="16x16" href="../../assets/images/favicon.png">

<?php echo $__env->yieldContent('center-css'); ?>
<!-- Custom CSS -->
<link href="../../dist/css/style.min.css" rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->


































<?php /**PATH F:\Github\PHP\Laravel\ProjectPHPTeam1\ProjectTeam1\resources\views/admin/html/css.blade.php ENDPATH**/ ?>